-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: sgrpg
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tblcity`
--

DROP TABLE IF EXISTS `tblcity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblcity` (
  `CityId` int NOT NULL AUTO_INCREMENT,
  `BoardId` int DEFAULT NULL,
  `CityName` varchar(255) NOT NULL,
  `CityBiome` varchar(255) DEFAULT NULL,
  `CityImage` longblob,
  `CityDescription` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`CityId`),
  KEY `tblcity_ibfk_1` (`BoardId`),
  CONSTRAINT `tblcity_ibfk_1` FOREIGN KEY (`BoardId`) REFERENCES `tblboard` (`BoardId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=267 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblcity`
--

LOCK TABLES `tblcity` WRITE;
/*!40000 ALTER TABLE `tblcity` DISABLE KEYS */;
INSERT INTO `tblcity` VALUES (185,54,'Arkania','Planície',NULL,'A capital.\nA majestosa cidade fortificada, situada no centro do país, é o coração político e cultural de Eldoria. Seu castelo imponente abriga o Imperador e sua corte.\nUma cidade central com terrenos planos, adequada para ser o centro político e cultural de Eldoria.'),(186,54,'Valerian','Litoral',NULL,'Uma cidade portuária movimentada, conhecida por seu comércio marítimo e próspero mercado. Localizada à beira-mar, com clima temperado e ambiente costeiro.'),(187,54,'Silvamore','Floresta',NULL,'Cidade localizada em meio a densas florestas, famosa por seus rangers habilidosos e produção de itens de couro e madeira. Rica em vegetação e vida selvagem.'),(188,54,'Thundertop','Montanha',NULL,'Uma cidade nas montanhas, onde anões e mineiros trabalham incansavelmente em busca de preciosos minérios e pedras preciosas. Terrenos rochosos e altos picos.'),(189,54,'Eldergrove','Floresta',NULL,'Conhecida por ser a morada de elfos sábios e sua conexão com a magia da natureza.'),(190,54,'Stonewall','Planaltos',NULL,'Uma cidade que se destaca por sua imponente muralha de pedra, protegendo seus habitantes das ameaças externas.'),(191,54,'Havenbrook','Floresta',NULL,'Localizada perto de um grande lago, é famosa por suas águas termais e fontes de cura.'),(192,54,'Frostforge','Tundra',NULL,'No extremo norte, uma cidade gelada que abriga habilidosos ferreiros e construtores de armas resistentes.'),(193,54,'Solaris','Campos',NULL,'Uma cidade dedicada ao conhecimento e à sabedoria, onde uma renomada universidade atrai estudiosos de todo o país.'),(194,54,'Alqendia','Deserto',NULL,'Cidade situada em um grande deserto, rica cultura árabe com venda de especiarias e sede da Guilda dos assassinos.'),(195,54,'Greenleaf','Campos',NULL,'Vila agrícola cercada por vastas plantações e campos férteis.'),(196,54,'Ambermill','Floresta',NULL,'Conhecida pela produção de joias de âmbar, situada em um ambiente florestal.'),(197,54,'Emberwood','Floresta',NULL,'Uma pequena vila em uma área arborizada, famosa pelos pirotécnicos.'),(198,54,'Ironhold','Montanha',NULL,'Vila próxima a mina de Frostforge, que fornece matéria-prima essencial para o reino.'),(199,54,'Goldenhold','Montanha',NULL,'Vila próxima a mina de Frostforge, que fornece matéria-prima essencial para o reino.'),(200,54,'Starfall','Planície',NULL,'Vila próxima a uma área de avistamento de estrelas, lar de astrônomos e estudiosos celestes.'),(201,54,'Misty Hollow','Floresta',NULL,'Vila escondida em uma densa névoa mágica, abriga místicos e bruxos renegados.'),(202,54,'Serpent\'s Cross','Floresta',NULL,'Vila à beira de uma vasta floresta, onde há uma concentração de criadores de cavalos.'),(203,54,'Driftwood','Litoral',NULL,'Vila de pescadores, com seus habitantes dependendo do mar para sustento.'),(204,54,'Thunderbreak','Marinha',NULL,'Vila localizada em meio ao mar, próximo a uma costa com varias montanhas, lar de ousados caçadores de dragões.');
/*!40000 ALTER TABLE `tblcity` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-16 14:53:47
